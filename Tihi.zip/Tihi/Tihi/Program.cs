﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tihi
{
    class Program
    {
        static void Main(string[] args)
        {
            Turtle teki = new Turtle();

            int index = 0;
            Console.Write("Mennyi étellel szeretnéd megetetni Tihit? ");
            Food[] etelek = new Food[int.Parse(Console.ReadLine())];

            string kaja = "";
            while (index != etelek.Length)
            {
                Console.Clear();
                Console.WriteLine("Teknős jóllakottsága: " + teki.getFedLevel() + ", boldogsága: " + teki.getHappiness());
                Console.Write($"({index + 1}. etetés) Mivel szeretnéd megetetni? (Salad/Crab): ");
                kaja = Console.ReadLine();
                while (kaja != "Salad" && kaja != "Crab")
                {
                    Console.Write("(Hiba) Mivel szeretnéd megetetni? (Salad/Crab): ");
                    kaja = Console.ReadLine();
                }
                if (kaja == "Salad")
                {
                    etelek[index] = new Salad();
                    teki.Eat(etelek[index]);
                }
                else
                {
                    Console.Write("Mekkora legyen a rák mérete? (1-10): ");
                    int meret = byte.Parse(Console.ReadLine());
                    while (meret <= 0 || meret >= 11)
                    {
                        Console.Write("(Hiba) Mekkora legyen a rák mérete? (1-10): ");
                        meret = int.Parse(Console.ReadLine());
                    }
                    etelek[index] = new Crab((byte)meret);
                    teki.Eat(etelek[index]);
                }
                index++;
            }
        }
    }
}
