﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tihi
{
    class Crab: Food
    {
        byte meret;

        public Crab(byte meret)
        {
            this.meret = meret;
        }

        public override int value()
        {
            return base.value() + (meret * 10);
        }
    }
}
