﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tihi
{
    class Turtle: Food
    {
        int happiness;
        int fedLevel;

        public void Eat(Food food)
        {
            fedLevel += food.value();

            if (fedLevel <= 500 && happiness <= 1000)
                happiness += 2 * food.value();
            else if (fedLevel > 500 && happiness > 0)
                happiness -= 2 * food.value();
            else
            {
                Console.WriteLine("A teknős tele lett!");
                return;
            }
        }

        public int getHappiness()
        {
            return happiness;
        }

        public int getFedLevel()
        {
            return fedLevel;
        }
    }
}
