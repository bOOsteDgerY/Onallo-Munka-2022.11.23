﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tihi
{
    class Salad: Food
    {
        int tapertek = 10;

        public override int value()
        {
            return base.value() + tapertek;
        }
    }
}
