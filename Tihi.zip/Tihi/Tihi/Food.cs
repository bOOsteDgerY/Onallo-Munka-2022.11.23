﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tihi
{
    abstract class Food
    {
        int tapertek = 0;

        public virtual int value()
        {
            return tapertek;
        }
    }
}
