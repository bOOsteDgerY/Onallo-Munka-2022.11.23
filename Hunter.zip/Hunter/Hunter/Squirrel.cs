﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hunter
{
    class Squirrel: Animal
    {
        const double squirrelFactor = 1.2;

        public override double getPrice()
        {
            return base.getPrice() * squirrelFactor;
        }

        public override string GetType()
        {
            return "Mókus " + base.GetType();
        }
    }
}
