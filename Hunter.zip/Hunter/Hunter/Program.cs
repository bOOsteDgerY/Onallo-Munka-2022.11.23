﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hunter
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal[] allatok = new Animal[3];

            allatok[0] = new Rabbit();
            allatok[1] = new Squirrel();
            allatok[2] = new PolarBear();

            for (int i = 0; i < allatok.Length; i++)
            {
                Console.WriteLine(allatok[i].GetType() + " " + allatok[i].getPrice());
            }
        }
    }
}
