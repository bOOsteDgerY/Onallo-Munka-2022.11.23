﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFurniture
{
    class Chair: Furniture
    {
        const double chairFactor = 1.2;
        int labszam;

        public Chair(int labszam)
        {
            this.labszam = labszam;
            idNovel();
        }

        public override double getPrice()
        {
            return base.getPrice() * chairFactor;
        }

        public override string Print()
        {
            return "Szék " + base.Print() + "\nLábszám: " + labszam + "\nÁr: " + getPrice();
        }
    }
}
