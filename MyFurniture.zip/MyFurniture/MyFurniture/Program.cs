﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFurniture
{
    class Program
    {
        static void Main(string[] args)
        {
            Furniture[] butorok = new Furniture[3];

            butorok[0] = new Table(130);
            butorok[1] = new Chair(4);
            butorok[2] = new Bed(200, 175);

            for (int i = 0; i < butorok.Length; i++)
            {
                Console.WriteLine(butorok[i].getId() + ".: " + butorok[i].Print() + "\n");
            }
        }
    }
}
