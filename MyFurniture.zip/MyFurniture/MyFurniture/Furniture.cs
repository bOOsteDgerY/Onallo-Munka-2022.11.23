﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFurniture
{
    abstract class Furniture
    {
        static double basePrice = 25000;
        static uint idCounter = 0;
        protected uint id;

        protected void idNovel()
        {
            id = ++idCounter;
        }

        public uint getId()
        {
            return id;
        }

        public virtual double getPrice()
        {
            return basePrice;
        }

        public virtual string Print()
        {
            return "tulajdonságai: ";
        }
    }
}
