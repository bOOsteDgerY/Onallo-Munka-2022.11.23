﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFurniture
{
    class Bed: Furniture
    {
        const double bedFactor = 2.4;
        int hossz;
        int szelesseg;

        public Bed(int hossz, int szelesseg)
        {
            this.hossz = hossz;
            this.szelesseg = szelesseg;
            idNovel();
        }

        public override double getPrice()
        {
            return base.getPrice() * bedFactor;
        }

        public override string Print()
        {
            return "Ágy " + base.Print() + "\nHossz: " + hossz + ", szélesség: " + szelesseg + "\nÁr: " + getPrice();
        }
    }
}
